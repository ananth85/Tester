﻿namespace Tester
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.button12 = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.button17 = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.button18 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.button19 = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.button20 = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.button21 = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.button22 = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.button23 = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.button24 = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.button25 = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.button26 = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.button27 = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.button28 = new System.Windows.Forms.Button();
            this.label29 = new System.Windows.Forms.Label();
            this.button29 = new System.Windows.Forms.Button();
            this.label30 = new System.Windows.Forms.Label();
            this.button30 = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.button31 = new System.Windows.Forms.Button();
            this.label32 = new System.Windows.Forms.Label();
            this.button32 = new System.Windows.Forms.Button();
            this.label33 = new System.Windows.Forms.Label();
            this.button33 = new System.Windows.Forms.Button();
            this.label34 = new System.Windows.Forms.Label();
            this.button34 = new System.Windows.Forms.Button();
            this.label35 = new System.Windows.Forms.Label();
            this.button35 = new System.Windows.Forms.Button();
            this.label36 = new System.Windows.Forms.Label();
            this.button36 = new System.Windows.Forms.Button();
            this.label37 = new System.Windows.Forms.Label();
            this.button37 = new System.Windows.Forms.Button();
            this.label38 = new System.Windows.Forms.Label();
            this.button38 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(222, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Show";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(8, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(208, 34);
            this.label1.TabIndex = 1;
            this.label1.Text = "Powerful sample. It shows syntax highlighting and many features.";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(8, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(208, 30);
            this.label2.TabIndex = 3;
            this.label2.Text = "Marker sample. It shows how to make marker tool.";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(222, 88);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "Show";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(8, 128);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(208, 30);
            this.label3.TabIndex = 5;
            this.label3.Text = "Custom style sample. This example shows how to create own custom style.";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(222, 128);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 4;
            this.button3.Text = "Show";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(8, 165);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(208, 56);
            this.label4.TabIndex = 7;
            this.label4.Text = "VisibleRangeChangedDelayed usage sample. This example shows how to highlight synt" +
    "ax for extremally large text by VisibleRangeChangedDelayed event.";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(222, 179);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 6;
            this.button4.Text = "Show";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(11, 41);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(205, 44);
            this.label5.TabIndex = 9;
            this.label5.Text = "Simplest custom syntax highlighting sample. It shows how to make custom syntax hi" +
    "ghlighting.";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(222, 46);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 8;
            this.button5.Text = "Show";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(8, 523);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(208, 26);
            this.label6.TabIndex = 11;
            this.label6.Text = "Joke sample :)";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(222, 518);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 10;
            this.button6.Text = "Show";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(315, 4);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(208, 41);
            this.label7.TabIndex = 13;
            this.label7.Text = "Simplest code folding sample. This example shows how to make simplest code foldin" +
    "g.";
            this.label7.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(529, 4);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 12;
            this.button7.Text = "Show";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(315, 87);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(208, 41);
            this.label8.TabIndex = 15;
            this.label8.Text = "Autocomplete sample. This example shows simplest way to create autocomplete funct" +
    "ionality.";
            this.label8.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(529, 98);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 23);
            this.button8.TabIndex = 14;
            this.button8.Text = "Show";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(315, 306);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(208, 59);
            this.label9.TabIndex = 17;
            this.label9.Text = "Dynamic syntax highlighting. This example finds the functions declared in the pro" +
    "gram and dynamically highlights all of their entry into the code of LISP.";
            this.label9.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(529, 320);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 23);
            this.button9.TabIndex = 16;
            this.button9.Text = "Show";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(315, 371);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(208, 45);
            this.label10.TabIndex = 19;
            this.label10.Text = "Syntax highlighting by XML description file. This example shows how to use XML fi" +
    "le for description of syntax highlighting.";
            this.label10.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(529, 378);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(75, 23);
            this.button10.TabIndex = 18;
            this.button10.Text = "Show";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(315, 425);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(208, 37);
            this.label11.TabIndex = 21;
            this.label11.Text = "This example supports IME entering mode and rendering of wide characters.";
            this.label11.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(529, 425);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(75, 23);
            this.button11.TabIndex = 20;
            this.button11.Text = "Show";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(8, 234);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(208, 26);
            this.label12.TabIndex = 23;
            this.label12.Text = "Powerfull C# source file editor";
            this.label12.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(222, 229);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(75, 23);
            this.button12.TabIndex = 22;
            this.button12.Text = "Show";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(8, 271);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(208, 26);
            this.label13.TabIndex = 25;
            this.label13.Text = "Example of image drawing";
            this.label13.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(222, 271);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(75, 23);
            this.button13.TabIndex = 24;
            this.button13.Text = "Show";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(315, 135);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(208, 41);
            this.label14.TabIndex = 27;
            this.label14.Text = "Autocomplete sample 2.\r\nThis example demonstrates more flexible variant of Autoco" +
    "mpleteMenu using.";
            this.label14.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(529, 141);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(75, 23);
            this.button14.TabIndex = 26;
            this.button14.Text = "Show";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // label15
            // 
            this.label15.Location = new System.Drawing.Point(315, 473);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(208, 23);
            this.label15.TabIndex = 29;
            this.label15.Text = "AutoIndent sample";
            this.label15.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(529, 468);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(75, 23);
            this.button15.TabIndex = 28;
            this.button15.Text = "Show";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(529, 511);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(75, 23);
            this.button16.TabIndex = 30;
            this.button16.Text = "Show";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(315, 517);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(208, 23);
            this.label16.TabIndex = 31;
            this.label16.Text = "Bookmarks sample";
            this.label16.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label17
            // 
            this.label17.Location = new System.Drawing.Point(8, 312);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(208, 26);
            this.label17.TabIndex = 33;
            this.label17.Text = "Logger sample. It shows how to add text with predefined style.";
            this.label17.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(222, 312);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(75, 23);
            this.button17.TabIndex = 32;
            this.button17.Text = "Show";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // label18
            // 
            this.label18.Location = new System.Drawing.Point(315, 271);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(208, 26);
            this.label18.TabIndex = 35;
            this.label18.Text = "Tooltip sample.";
            this.label18.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(529, 271);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(75, 23);
            this.button18.TabIndex = 34;
            this.button18.Text = "Show";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // label19
            // 
            this.label19.Location = new System.Drawing.Point(8, 351);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(208, 26);
            this.label19.TabIndex = 37;
            this.label19.Text = "Split sample. This example shows how to make split-screen mode.";
            this.label19.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(222, 351);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(75, 23);
            this.button19.TabIndex = 36;
            this.button19.Text = "Show";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // label20
            // 
            this.label20.Location = new System.Drawing.Point(8, 392);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(208, 26);
            this.label20.TabIndex = 39;
            this.label20.Text = "Lazy loading sample.";
            this.label20.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(222, 392);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(75, 23);
            this.button20.TabIndex = 38;
            this.button20.Text = "Show";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // label21
            // 
            this.label21.Location = new System.Drawing.Point(315, 559);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(208, 23);
            this.label21.TabIndex = 41;
            this.label21.Text = "Console sample";
            this.label21.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(529, 554);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(75, 23);
            this.button21.TabIndex = 40;
            this.button21.Text = "Show";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // label22
            // 
            this.label22.Location = new System.Drawing.Point(315, 53);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(208, 26);
            this.label22.TabIndex = 43;
            this.label22.Text = "Custom code folding sample.";
            this.label22.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(529, 48);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(75, 23);
            this.button22.TabIndex = 42;
            this.button22.Text = "Show";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // label23
            // 
            this.label23.Location = new System.Drawing.Point(8, 437);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(208, 26);
            this.label23.TabIndex = 45;
            this.label23.Text = "Bilingual highlighter sample";
            this.label23.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(222, 431);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(75, 23);
            this.button23.TabIndex = 44;
            this.button23.Text = "Show";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // label24
            // 
            this.label24.Location = new System.Drawing.Point(8, 478);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(208, 26);
            this.label24.TabIndex = 47;
            this.label24.Text = "Hyperlink sample";
            this.label24.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(222, 472);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(75, 23);
            this.button24.TabIndex = 46;
            this.button24.Text = "Show";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // label25
            // 
            this.label25.Location = new System.Drawing.Point(614, 3);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(208, 32);
            this.label25.TabIndex = 49;
            this.label25.Text = "Custom TextSource sample. This example shows how to display very large string\r\n";
            this.label25.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(828, 4);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(75, 23);
            this.button25.TabIndex = 48;
            this.button25.Text = "Show";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // label26
            // 
            this.label26.Location = new System.Drawing.Point(633, 51);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(189, 23);
            this.label26.TabIndex = 51;
            this.label26.Text = "Hints sample";
            this.label26.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(828, 46);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(75, 23);
            this.button26.TabIndex = 50;
            this.button26.Text = "Show";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // label27
            // 
            this.label27.Location = new System.Drawing.Point(633, 87);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(189, 49);
            this.label27.TabIndex = 53;
            this.label27.Text = "ReadOnly blocks sample. Are you needed readonly blocks of text? Yep, we can do it" +
    "...";
            this.label27.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(828, 88);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(75, 23);
            this.button27.TabIndex = 52;
            this.button27.Text = "Show";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // label28
            // 
            this.label28.Location = new System.Drawing.Point(633, 139);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(189, 49);
            this.label28.TabIndex = 55;
            this.label28.Text = "Predefined styles sample. Here we create large text with predefined styles, hyper" +
    "links and tooltips...";
            this.label28.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(828, 140);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(75, 23);
            this.button28.TabIndex = 54;
            this.button28.Text = "Show";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // label29
            // 
            this.label29.Location = new System.Drawing.Point(633, 194);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(189, 35);
            this.label29.TabIndex = 57;
            this.label29.Text = "This sample shows how to use macros for hard formatting of the code.";
            this.label29.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(828, 195);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(75, 23);
            this.button29.TabIndex = 56;
            this.button29.Text = "Show";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // label30
            // 
            this.label30.Location = new System.Drawing.Point(633, 244);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(189, 24);
            this.label30.TabIndex = 59;
            this.label30.Text = "How to use OpenType fonts.";
            this.label30.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(828, 240);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(75, 23);
            this.button30.TabIndex = 58;
            this.button30.Text = "Show";
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // label31
            // 
            this.label31.Location = new System.Drawing.Point(633, 293);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(189, 24);
            this.label31.TabIndex = 61;
            this.label31.Text = "Ruler sample.";
            this.label31.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(828, 288);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(75, 23);
            this.button31.TabIndex = 60;
            this.button31.Text = "Show";
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // label32
            // 
            this.label32.Location = new System.Drawing.Point(315, 181);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(208, 41);
            this.label32.TabIndex = 63;
            this.label32.Text = "Autocomplete sample 3.\r\n How to make dynamic autocomplete menu.";
            this.label32.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(529, 187);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(75, 23);
            this.button32.TabIndex = 62;
            this.button32.Text = "Show";
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // label33
            // 
            this.label33.Location = new System.Drawing.Point(315, 223);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(208, 41);
            this.label33.TabIndex = 65;
            this.label33.Text = "Autocomplete sample 4.\r\nHow to make intellisense menu with predefined list of cla" +
    "sses and methods.";
            this.label33.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(529, 229);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(75, 23);
            this.button33.TabIndex = 64;
            this.button33.Text = "Show";
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Click += new System.EventHandler(this.button33_Click);
            // 
            // label34
            // 
            this.label34.Location = new System.Drawing.Point(633, 335);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(189, 24);
            this.label34.TabIndex = 67;
            this.label34.Text = "Document map sample.";
            this.label34.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(828, 330);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(75, 23);
            this.button34.TabIndex = 66;
            this.button34.Text = "Show";
            this.button34.UseVisualStyleBackColor = true;
            this.button34.Click += new System.EventHandler(this.button34_Click);
            // 
            // label35
            // 
            this.label35.Location = new System.Drawing.Point(633, 382);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(189, 24);
            this.label35.TabIndex = 69;
            this.label35.Text = "DiffMerge sample.";
            this.label35.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(828, 377);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(75, 23);
            this.button35.TabIndex = 68;
            this.button35.Text = "Show";
            this.button35.UseVisualStyleBackColor = true;
            this.button35.Click += new System.EventHandler(this.button35_Click);
            // 
            // label36
            // 
            this.label36.Location = new System.Drawing.Point(633, 425);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(189, 24);
            this.label36.TabIndex = 71;
            this.label36.Text = "Custom scrollbars sample.";
            this.label36.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(828, 420);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(75, 23);
            this.button36.TabIndex = 70;
            this.button36.Text = "Show";
            this.button36.UseVisualStyleBackColor = true;
            this.button36.Click += new System.EventHandler(this.button36_Click);
            // 
            // label37
            // 
            this.label37.Location = new System.Drawing.Point(633, 468);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(189, 24);
            this.label37.TabIndex = 73;
            this.label37.Text = "Custom wordwrap sample.";
            this.label37.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button37
            // 
            this.button37.Location = new System.Drawing.Point(828, 463);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(75, 23);
            this.button37.TabIndex = 72;
            this.button37.Text = "Show";
            this.button37.UseVisualStyleBackColor = true;
            this.button37.Click += new System.EventHandler(this.button37_Click);
            // 
            // label38
            // 
            this.label38.Location = new System.Drawing.Point(633, 510);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(189, 24);
            this.label38.TabIndex = 75;
            this.label38.Text = "AutoIndentChars sample.";
            this.label38.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button38
            // 
            this.button38.Location = new System.Drawing.Point(828, 505);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(75, 23);
            this.button38.TabIndex = 74;
            this.button38.Text = "Show";
            this.button38.UseVisualStyleBackColor = true;
            this.button38.Click += new System.EventHandler(this.button38_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(915, 585);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.button38);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.button37);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.button36);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.button35);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.button34);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.button33);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.button32);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.button31);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.button30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.button29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.button28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.button27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.button26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.button24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.DoubleClick += new System.EventHandler(this.MainForm_DoubleClick);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Button button38;
    }
}